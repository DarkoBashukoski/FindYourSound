import json
import csv
import os

os.remove('data.csv')
f = open('MOM.json', 'r', encoding='utf-8')
out = open('data.csv', 'w', encoding='utf-8')

writer = csv.writer(out)

full_data = json.load(f)

cards = dict()
 
for x in full_data["data"]["cards"]:
    if x["name"] not in cards.keys():
        cards[x["name"]] = x
        
header = ["CardName", "Colors", "Defense", "Layout", "Loyalty", "ManaCost", "ManaValue", "Power", "Text", "Set", "Type"]
data = []

for key in cards:
    x = cards[key]
    row = []
    row.append(x["name"])
    row.append(x["colors"])
    
    if ("defense" in x.keys()):
        row.append(x["defense"])
    elif "toughness" in x.keys():
        row.append(int(x["toughness"]))
    else:
        row.append(0)
    
    row.append(x["layout"])
    row.append(x["loyalty"] if "loyalty" in x.keys() else 0)
    row.append(x["manaCost"] if "manaCost" in x.keys() else "")
    row.append(x["manaValue"])
    row.append(x["power"] if "power" in x.keys() else 0)
    row.append(x["text"] if "text" in x.keys() else "")
    row.append(x["setCode"])
    row.append(x["type"].replace("—", "-") if "type" in x.keys() else "")
    
    data.append(row)

writer.writerow(header)
writer.writerows(data)
    
f.close()
out.close()