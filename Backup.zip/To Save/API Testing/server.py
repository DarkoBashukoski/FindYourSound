import socket
import requests

HEADER_RESPONSE_200 = """HTTP/1.1 200 OK\r
content-type: %s\r
content-length: %d\r
connection: Close\r
\r
"""

HEADER_RESPONSE_301 = """HTTP/1.1 301 Moved Permanently\r
location: %s\r
content-type: %s\r
content-length: %d\r
connection: Close
\r
"""

BODY_RESPONSE_301 = """<!doctype html>
<h1>301 Moved Permanently</h1>
<p>Redirecting you to %s.</p>"""

HEADER_RESPONSE_400 = """HTTP/1.1 400 Bad Request\r
content-type: text/html\r
content-length: %d\r
connection: Close\r
\r
"""

BODY_RESPONSE_400 = """<!doctype html>
<h1>400 Bad Request</h1>
<p>%s</p>"""

RESPONSE_404 = """HTTP/1.1 404 Not found\r
content-type: text/html\r
connection: Close\r
\r
<!doctype html>
<h1>404 Page not found</h1>
<p>Page cannot be found.</p>
"""

BODY_RESPONSE_405 = """<!doctype html>
<h1>405 Method Not Allowed</h1>
<p>This page only accepts %s methods.</p>"""

HEADER_RESPONSE_405 = """HTTP/1.1 405 Method Not Allowed\r
content-type: text/html\r
content-length: %d
connection: Close\r
\r
"""

def send_host_error(client):
    body = BODY_RESPONSE_400 % "Missing host header"
    header = HEADER_RESPONSE_400 % (len(body))
    client.write(header.encode("utf-8"))
    client.write(body.encode("utf-8"))
    raise AssertionError(f"Missing host header")


def send_value_error(client):
    body = BODY_RESPONSE_400 % "Bad Request"
    header = HEADER_RESPONSE_400 % (len(body))
    client.write(header.encode("utf-8"))
    client.write(body.encode("utf-8"))
    raise AssertionError("Bad Request")


def process_request(connection, address):
    client = connection.makefile("wrb")
    line = client.readline().decode("utf-8").strip()

    try:
        method, uri, version = line.split()
        if version != "HTTP/1.1":
            send_version_error(client, version)
        if not len(uri) > 0 and uri[0] != "/":
            raise IOError

        headers = parse_headers(client)
        
        if uri.startswith("/auth"):
            authenticate_client(method, client)
        

    except AssertionError as e:
        print(f"Invalid request {line} ({e})")
    except ValueError as e:
        send_value_error(client)
    except IOError:
        client.write(RESPONSE_404.encode("utf-8"))
    finally:
        client.close()


def authenticate_client(method, client):
    if method != "GET":
        body = BODY_RESPONSE_405 % "GET"
        header = HEADER_RESPONSE_405 % (len(body))
        client.write(header.encode("utf-8"))
        client.write(body.encode("utf-8"))
        raise AssertionError(f"Method {method} Not Allowed")
    
    url = 'https://login.microsoftonline.com/beterna.com/oauth2/v2.0/token'
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    auth_info = {
        "grant_type": "client_credentials",
        "scope": "https://usnconeboxax1aos.cloud.onebox.dynamics.com/.default",
        "client_id": "f55d7768-f943-4627-90bd-7af858cdf28f",
        "client_secret": "mff8Q~lXMuQ-mBZKtg6FG0OTdUGYFo3tWtOBGbb4"
    }
    
    r = requests.post(url, auth_info, headers)
    
    body = str(r.json())
    body = body.replace("'", '"')
    head = HEADER_RESPONSE_200 % ("application/json", len(body))
    client.write(head.encode("utf-8"))
    client.write(body.encode("utf-8"))

def parse_headers(client):
    headers = dict()
    while True:
        line = client.readline().decode("utf-8").strip()
        if not line:
            return headers
        key, value = line.split(":", 1)
        headers[key.strip().lower()] = value.strip()


def get_url_params(url):
    out = dict()
    if "?" not in url:
        return out
    params = url.split("?")[-1]
    for x in params.split("&"):
        p = x.split("=")
        out[p[0].strip()] = p[1].strip()
    return out


def get_body_params(body):
    out = dict()
    if len(body.strip()) == 0:
        return out
    for x in body.split("&"):
        kvp = x.split("=")
        out[kvp[0].strip()] = kvp[1].strip()
    return out


def send_version_error(client, version):
    body = BODY_RESPONSE_400 % f"Version {version} not recognized by server"
    header = HEADER_RESPONSE_400 % (len(body))
    client.write(header.encode("utf-8"))
    client.write(body.encode("utf-8"))
    raise AssertionError(f"Version {version} Not Allowed")


def main(port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("", port))
    server.listen(1)

    print("Listening on %d" % port)

    while True:
        connection, address = server.accept()
        print("[%s:%d] CONNECTED" % address)
        process_request(connection, address)
        connection.close()
        print("[%s:%d] DISCONNECTED" % address)


if __name__ == "__main__":
    main(8080)
